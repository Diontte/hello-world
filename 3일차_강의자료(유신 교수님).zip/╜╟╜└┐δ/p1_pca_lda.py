from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis	
import matplotlib.pyplot as plt

iris = datasets.load_iris()
X = iris.data # rows of features
y = iris.target # integer labels
target_names = iris.target_names # label names

print(X)
print(y)

pca = PCA(n_components = 2)
pca.fit(X)
reduced = pca.transform(X)

print(reduced)
lda = LinearDiscriminantAnalysis(n_components = 2)
lda.fit(X, y)
discriminated = lda.transform(X)

plt.figure()
plt.subplot(2,1,1)
plt.scatter(reduced[:,0], reduced[:,1], c=y)
plt.subplot(2,1,2)
plt.scatter(discriminated[:,0], discriminated[:,1], c=y)
plt.show()