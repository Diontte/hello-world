from sklearn import datasets
from sklearn.linear_model import LogisticRegression
wine = datasets.load_wine()
X = wine.data # rows of features
y = wine.target # integer labels
# 4번문제: backward wrapper
num_features = len(X[0])
removed_features = []

for i in range(num_features - 7):
	selected_feature = None
	max_score = -1
	for j in range(num_features):
		if j in removed_features:
			continue
		current_features = list(set(range(13)) - set(removed_features + [j]))
		sel_X = X[:, current_features]
		# implement here

		#################################
	removed_features.append(selected_feature)
	print(removed_features)
