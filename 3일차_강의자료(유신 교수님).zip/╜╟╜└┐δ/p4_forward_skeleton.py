from sklearn import datasets
from sklearn.linear_model import LogisticRegression
wine = datasets.load_wine()
X = wine.data # rows of features
y = wine.target # integer labels
# 4번문제: forward wrapper
num_features = len(X[0])
features = []
for i in range(7):
	selected_feature = None
	max_precision = -1
	for j in range(num_features):
		if j in features:
			continue
		current_features = features.copy() # copy the current selection
		current_features.append(j) # and add what we are considering now
		sel_X = X[:, current_features]
		# implement here


		#################################
	features.append(selected_feature)
	print(features)
