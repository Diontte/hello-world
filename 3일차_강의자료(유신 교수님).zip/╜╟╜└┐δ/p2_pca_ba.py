from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression

wine = datasets.load_wine()
X = wine.data # rows of features
y = wine.target # integer labels
print(X)
print(y)
#print(X[0])
#print(len(X[0]))
logi = LogisticRegression()
logi.fit(X, y)
print(logi.predict(X))
#score(X, y[, sample_weight])	Returns
#the mean accuracy on the given test data and labels.
print(logi.score(X, y))

for i in range(1, 13):
	# i: 1, 2, 3, ..., 12
	pca = PCA(n_components=i)
	reduced = pca.fit_transform(X)
	logiPCA = LogisticRegression()
	logiPCA.fit(reduced, y)
	print(i, logiPCA.score(reduced, y))