from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier

# 3번 문제

wine = datasets.load_wine()
X = wine.data # rows of features
y = wine.target # integer labels

dt = DecisionTreeClassifier()
dt.fit(X, y)

print(y)
print(dt.predict(X))
print(dt.score(X, y))

# print the feature importance for the wine dataset
print(dt.feature_importances_)
print(sum(dt.feature_importances_))