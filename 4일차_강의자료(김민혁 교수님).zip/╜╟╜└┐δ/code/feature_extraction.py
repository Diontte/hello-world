import cv2
import numpy as np


def feature_extraction(img):
    """
    This function computes HoG descriptors of the target image.

    :param img: a height x width x channels matrix

    :return: a N x feature_size matrix.
    """

    # HoG parameters
    win_size = (32, 32)
    block_size = (32, 32)
    block_stride = (16, 16)
    cell_size = (16, 16)
    nbins = 9
    deriv_aperture = 1
    win_sigma = 4
    histogram_norm_type = 0
    l2_hys_threshold = 2.0000000000000001e-01
    gamma_correction = 0
    nlevels = 64

    # HoG descriptor
    hog = cv2.HOGDescriptor(win_size, block_size, block_stride, cell_size, nbins,
                            deriv_aperture, win_sigma, histogram_norm_type, l2_hys_threshold,
                            gamma_correction, nlevels)

    xs, ys = np.meshgrid(np.arange(0, img.shape[0], 20), np.arange(0, img.shape[1], 20))
    locations = np.stack((xs.ravel(), ys.ravel()), axis=1).tolist()
    return hog.compute(img, locations=locations).reshape([-1, 36])
