import cv2
import numpy as np

from feature_extraction import feature_extraction


def build_vocabulary(image_paths, vocab_size):
    """
    This function will sample feature descriptors from the training images,
    cluster them with kmeans, and the return the cluster centers.

    :param image_paths: a N array of string where each string is an image path
    :param vocab_size: the size of the vocabulary.

    :return: a vocab_size x feature_size matrix. center positions of k-means clustering.
    """

    # Your code here. You should also change the return value.
    all_features = []
    for path in image_paths:
        img = cv2.imread(path)[:, :, ::-1]  # 이미지 읽기
        features = feature_extraction(img)  # 이미지에서 feature 추출
        all_features.append(features)  # feature들을 리스트에 추가

    all_features = np.concatenate(all_features, axis=0)  # 모든 feature들을 붙여서 하나의 matrix 생성
    # k-means clustering 수행
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-4)
    flags = cv2.KMEANS_RANDOM_CENTERS
    compactness, labels, centers = cv2.kmeans(all_features, vocab_size, None, criteria, 10, flags)
    return centers  # k-means clustring 결과의 center 값들을 반환

    #return np.zeros((vocab_size, 36))
