import cv2
from matplotlib import pyplot as plt


img = cv2.imread('data/test/Bedroom/image_0003.jpg')[:, :, ::-1]

plt.imshow(img)
plt.show()

img[50:100, 50:100, :] = 0  # 일부 영역을 0으로 채운다.
plt.imshow(img)
plt.show()
