import numpy as np
from sklearn import svm


def svm_classify(train_image_feats, train_labels, test_image_feats):
    """
    This function should train a linear SVM for every category (i.e., one vs all)
    and then use the learned linear classifiers to predict the category of every
    test image. Every test feature will be evaluated with all 15 SVMs and the
    most confident SVM will 'win'.

    :param train_image_feats:
        an N x d matrix, where d is the dimensionality of the feature representation.
    :param train_labels:
        an N array, where each entry is a string indicating the ground truth category
        for each training image.
    :param test_image_feats:
        an M x d matrix, where d is the dimensionality of the feature representation.
        You can assume M = N unless you've modified the starter code.

    :return:
        an M array, where each entry is a string indicating the predicted
        category for each test image.
    """

    categories = np.unique(train_labels)

    # Your code here. You should also change the return value.
    categories = np.unique(train_labels)

    predicted_categories = []
    models = []

    for c in range(categories.size):
        label = (categories[c] == train_labels).astype(np.int32)
        label[label == 0] = -1

        clf = svm.LinearSVC()
        clf.fit(train_image_feats, label)
        models.append(clf)

    for f in range(test_image_feats.shape[0]):
        predictions = []

        for clf in models:
            score = clf.decision_function(test_image_feats[f, :].reshape(1, -1))
            predictions.append(score)

        predictions = np.array(predictions)
        inds = np.argsort(predictions, axis=0)[::-1]
        predicted_categories.append(categories[inds[0]])

    return np.squeeze(np.array(predicted_categories))

    #return np.array([categories[0]] * 1500)
