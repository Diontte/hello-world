import numpy as np

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import BaggingClassifier


def sample_all(dataset):
    sub_dataset = dataset
    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


# Subsampling
def sub_sample(dataset, subsample_size=0.25):
    '''######################################################
    이곳에 원본 데이터셋(dataset)을 여러개의 subsample로 나누는 함수를 구현해주세요.
    dataset은 N X (M+1)의 크기를 가지고 있습니다.
    N 행의 dataset중 subsample_size에 맞게 랜덤샘플링을 하시면 됩니다.
    (ex. dataset[1, 3, 7] 은 dataset의 1, 3, 7 번째 데이터를 리턴합니다.)
    dataset의 마지막 열 (dataset[:, -1]) 은 그 데이터의 label이 담겨 있습니다.
    label은 심장병이면 1, 심장병이 아니면 0을 리턴해주세요.
    (심장병 유무는 실습 슬라이드 page 3를 참고해주세요)

    :param dataset: 원본 데이터셋
    :param subsample_size: float형, 원본 데이터셋에서 sub sampling할 비율 (ex. subsample_size 값이 0.25이면 원본 데이터셋의 1/4을 sub sampling 한다는 뜻)
    :return: subsample dataset, subsample label
    Hint! np.random.randint() 함수 등이 필요할 수도 있습니다.
    ######################################################'''

    '''''''''''''''''''''''''''''''''''''''''''''''''''
    이곳에 구현해주세요!
    '''''''''''''''''''''''''''''''''''''''''''''''''''



    '''''''''''''''''''''''''''''''''''''''''''''''''''
    '''''''''''''''''''''''''''''''''''''''''''''''''''


def bagging(train_dataset, test_dataset, num_trial, sample_size):
    models = []
    for i in range(num_trial):
        sub_train_dataset, sub_train_label = sub_sample(train_dataset, sample_size)

        '''
        본 과제에서는 분류기로 SKLearn package에 있는 DecisionTreeClassifier를 사용합니다.
        '''
        model = DecisionTreeClassifier(max_depth=1)
        model.fit(sub_train_dataset, sub_train_label)
        models.append(model)

    test_dataset, test_label = sample_all(test_dataset)
    '''######################################################
    이곳에 학습된 분류기들(models)을 활용하여 bagging 알고리즘을 구현해 주세요
    최종 예측 결과를 final_prediction 변수에 입력해주세요
    Hint! model.predict() 함수 등이 필요할 수도 있습니다.
    ######################################################'''


    '''''''''''''''''''''''''''''''''''''''''''''''''''
    이곳에 구현해주세요!
    '''''''''''''''''''''''''''''''''''''''''''''''''''


    final_prediction =
    '''''''''''''''''''''''''''''''''''''''''''''''''''
    '''''''''''''''''''''''''''''''''''''''''''''''''''

    accuracy = accuracy_score(test_label, final_prediction)


    ''''''
    sk_model = BaggingClassifier(base_estimator=DecisionTreeClassifier(max_depth=1), n_estimators=num_trial, max_samples=sample_size)
    sk_train_dataset, sk_train_label = sample_all(train_dataset)
    sk_model.fit(sk_train_dataset, sk_train_label)
    sk_prediction = sk_model.predict(test_dataset)
    sk_accuracy = accuracy_score(test_label, sk_prediction)
    ''''''

    return accuracy, sk_accuracy
