import numpy as np

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import AdaBoostClassifier


def sample_all(dataset):
    sub_dataset = dataset
    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


# Subsampling
def sub_sample_with_weight(dataset, subsample_size, weights):
    if type(subsample_size) == int:
        sub_dataset = dataset[np.random.choice(len(dataset), subsample_size, p=weights)]
    elif type(subsample_size) == float:
        sub_dataset = dataset[np.random.choice(len(dataset), int(len(dataset) * subsample_size), p=weights)]

    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


def ada_boosting(train_dataset_, test_dataset, num_trial, sample_size):
    # Naive ada boost
    train_dataset, train_label = sample_all(train_dataset_)
    weights = np.ones(len(train_dataset))/len(train_dataset)
    models = []
    alphas = []
    for i in range(num_trial):
        model = DecisionTreeClassifier(max_depth=1, random_state=1)
        model.fit(train_dataset, train_label, sample_weight=weights)
        models.append(model)
        model_prediction = model.predict(train_dataset)
        incorrect = 1.0 * (model_prediction != train_label)
        error = np.dot(weights, incorrect) / sum(weights)
        alpha = 0.5 * np.log((1 - error) / error)
        alphas.append(alpha)
        weights *= np.exp([alpha if x == 1 else -alpha for x in incorrect])
        weights = weights / np.sum(weights)

    test_dataset, test_label = sample_all(test_dataset)
    models_prediction = [alphas[i] * (2.0 * models[i].predict(test_dataset) - 1.0) for i in range(len(models))]
    strong_classifier_prediction = (np.sign(np.sum(models_prediction, axis=0)) + 1.0) / 2.0
    accuracy = accuracy_score(test_label, strong_classifier_prediction)

    ''''''
    sk_model = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=1), n_estimators=num_trial)
    sk_train_dataset, sk_train_label = sample_all(train_dataset_)
    sk_model.fit(sk_train_dataset, sk_train_label)
    sk_prediction = sk_model.predict(test_dataset)
    sk_accuracy = accuracy_score(test_label, sk_prediction)
    ''''''

    return accuracy, sk_accuracy
