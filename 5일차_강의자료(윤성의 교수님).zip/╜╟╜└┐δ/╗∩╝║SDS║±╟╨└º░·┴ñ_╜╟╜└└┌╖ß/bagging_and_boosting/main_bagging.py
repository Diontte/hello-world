import csv

from Bagging import *



# Load data from csv file
def load_csv(filename):
    dataset = []
    with open(filename, 'r') as file:
        reader = csv.reader(file, quoting=csv.QUOTE_NONNUMERIC)
        for data in reader:
            if not data:
                continue
            else:
                dataset.append(data)

    return np.asarray(dataset)


# Split train and test
def split_train_and_test_with_folding(dataset, num_fold):
    folds = np.array_split(dataset, num_fold)
    output = []
    for i in range(len(folds)):
        output.append((np.concatenate([fold for j, fold in enumerate(folds) if i != j]), folds[i]))

    return output

dataset = load_csv('HeartDisease.csv')
split_dataset = split_train_and_test_with_folding(dataset, 5)

bag_acc = []
sk_bag_acc = []

for i, (train_dataset, test_dataset) in enumerate(split_dataset):
    print("[[ FOLD " + str(i) + " ]]")
    train_dataset_for_bagging = np.array(train_dataset)
    test_dataset_for_bagging = np.array(test_dataset)
    train_dataset_for_boosting = np.array(train_dataset)
    test_dataset_for_boosting = np.array(test_dataset)

    bagging_accuracies = []
    sk_bagging_accuracies = []


    for size in [1, 5, 10, 50, 100, 500]:
        bagging_accuracy, sk_bagging_accuracy = bagging(train_dataset_for_bagging, test_dataset_for_bagging, size, 0.25)
        bagging_accuracies.append(bagging_accuracy)
        sk_bagging_accuracies.append(sk_bagging_accuracy)



        print("[" + str(size) + "] bagging_accuracy\t: " + ("%.3f" % bagging_accuracy) + ", sk_bagging_accuracy\t: " + (
                    "%.3f" % sk_bagging_accuracy))

    print("")

    bag_acc.append(bagging_accuracies)
    sk_bag_acc.append(sk_bagging_accuracies)


mean_bag_acc = np.mean(bag_acc, axis=0)
mean_sk_bag_acc = np.mean(sk_bag_acc, axis=0)


print("[[ MEAN ]]")
for i, size in enumerate([1, 5, 10, 50, 100, 500]):
    print("[" + str(size) + "] bagging_accuracy\t: " + ("%.3f" % mean_bag_acc[i]) + ", sk_bagging_accuracy\t: " + (
                "%.3f" % mean_sk_bag_acc[i]))
