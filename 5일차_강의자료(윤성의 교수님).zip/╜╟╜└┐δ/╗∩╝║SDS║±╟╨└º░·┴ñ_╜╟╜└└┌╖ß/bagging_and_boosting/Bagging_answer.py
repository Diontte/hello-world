import numpy as np

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import BaggingClassifier


def sample_all(dataset):
    sub_dataset = dataset
    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


# Subsampling
def sub_sample(dataset, subsample_size):
    if type(subsample_size) == int:
        sub_dataset = dataset[np.random.randint(len(dataset), size=subsample_size)]
    elif type(subsample_size) == float:
        sub_dataset = dataset[np.random.randint(len(dataset), size=int(len(dataset) * subsample_size))]

    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)



def bagging(train_dataset, test_dataset, num_trial, sample_size):
    models = []
    for i in range(num_trial):
        sub_train_dataset, sub_train_label = sub_sample(train_dataset, sample_size)

        model = DecisionTreeClassifier(max_depth=1)
        model.fit(sub_train_dataset, sub_train_label)
        models.append(model)

    test_dataset, test_label = sample_all(test_dataset)
    sum_prediction = np.zeros(len(test_dataset))
    for model in models:
        model_prediction = model.predict(test_dataset)
        sum_prediction = sum_prediction + model_prediction

    final_prediction = sum_prediction/len(models)
    final_prediction = 1.0 * (final_prediction > 0.5)

    accuracy = accuracy_score(test_label, final_prediction)

    ''''''
    sk_model = BaggingClassifier(base_estimator=DecisionTreeClassifier(max_depth=1), n_estimators=num_trial, max_samples=sample_size)
    sk_train_dataset, sk_train_label = sample_all(train_dataset)
    sk_model.fit(sk_train_dataset, sk_train_label)
    sk_prediction = sk_model.predict(test_dataset)
    sk_accuracy = accuracy_score(test_label, sk_prediction)
    ''''''

    return accuracy, sk_accuracy
