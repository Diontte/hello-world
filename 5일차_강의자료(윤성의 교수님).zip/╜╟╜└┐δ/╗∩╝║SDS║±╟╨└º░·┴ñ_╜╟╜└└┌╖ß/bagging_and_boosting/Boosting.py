import numpy as np

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import AdaBoostClassifier


def sample_all(dataset):
    sub_dataset = dataset
    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


# Subsampling
def sub_sample_with_weight(dataset, subsample_size, weights):
    if type(subsample_size) == int:
        sub_dataset = dataset[np.random.choice(len(dataset), subsample_size, p=weights)]
    elif type(subsample_size) == float:
        sub_dataset = dataset[np.random.choice(len(dataset), int(len(dataset) * subsample_size), p=weights)]

    return sub_dataset[:, :-1], 1.0 * (sub_dataset[:, -1] > 0)


def ada_boosting(train_dataset_, test_dataset, num_trial, sample_size):
    # Naive ada boost
    train_dataset, train_label = sample_all(train_dataset_)
    weights = np.ones(len(train_dataset))/len(train_dataset)
    models = []
    alphas = []
    for i in range(num_trial):
        model = DecisionTreeClassifier(max_depth=1, random_state=1)
        model.fit(train_dataset, train_label, sample_weight=weights)
        models.append(model)

        '''######################################################
        이곳에 학습된 분류기들(models)을 활용하여 boosting 알고리즘의 weight 계산하는 부분을 구현해 주세요
        약분류기(model)은 주어진 data에 대하여 심장병인지 (True) 아닌지 (False)를 리턴합니다.
        (ex. int(True) == 1, int(False) == 0)
        weight를 계산하는 식은 강의 슬라이드 page 14에 나와 있습니다.
        Hint! np.exp(), np.sum(), np.log(), np.dot(), model.predict() 함수 등이 필요할 수도 있습니다. 
        ######################################################'''

        '''''''''''''''''''''''''''''''''''''''''''''''''''
        이곳에 구현해주세요!
        '''''''''''''''''''''''''''''''''''''''''''''''''''

        weights =
        '''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''

    test_dataset, test_label = sample_all(test_dataset)

    '''######################################################
    이곳에 학습된 분류기들(models)을 활용하여 boosting 알고리즘의 strong classifier 계산하는 부분을 구현해 주세요.
    strong classifier를 계산하는 식은 강의 슬라이드 page 15에 나와 있습니다. 
    최종 예측 결과를 strong_classifier_prediction 변수에 입력해주세요
    Hint! models[i].predict(), np.sign 함수 등이 필요할 수도 있습니다.
    ######################################################'''

    '''''''''''''''''''''''''''''''''''''''''''''''''''
    이곳에 구현해주세요!
    '''''''''''''''''''''''''''''''''''''''''''''''''''

    strong_classifier_prediction =
    '''''''''''''''''''''''''''''''''''''''''''''''''''
    '''''''''''''''''''''''''''''''''''''''''''''''''''
    accuracy = accuracy_score(test_label, strong_classifier_prediction)

    ''''''
    sk_model = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=1), n_estimators=num_trial)
    sk_train_dataset, sk_train_label = sample_all(train_dataset_)
    sk_model.fit(sk_train_dataset, sk_train_label)
    sk_prediction = sk_model.predict(test_dataset)
    sk_accuracy = accuracy_score(test_label, sk_prediction)
    ''''''

    return accuracy, sk_accuracy
