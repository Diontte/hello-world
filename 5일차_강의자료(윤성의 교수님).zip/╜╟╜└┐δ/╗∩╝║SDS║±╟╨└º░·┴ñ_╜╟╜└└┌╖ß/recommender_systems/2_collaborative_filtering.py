import numpy as np
import pandas as pd


# read csv file using pandas library
ratings = pd.read_csv("ratings.csv")

print("=== Data Summary ===")
print("number of users: %d, number of items: %d, rating-values from %.1f to %.1f"
      % (ratings["user-id"].max(), ratings["item-id"].max(),
         ratings["rating-value"].min(), ratings["rating-value"].max()))
print("user-id ranges from %d to %d, item-id ranges from %d to %d"
      % (ratings["user-id"].min(), ratings["user-id"].max(),
         ratings["item-id"].min(), ratings["item-id"].max()))
print("====================")

# build matrix P
P = np.zeros([ratings["user-id"].max(), ratings["item-id"].max()])
for _, rating in ratings.iterrows():
    user_idx = int(rating["user-id"]) - 1
    item_idx = int(rating["item-id"]) - 1
    rating_value = float(rating["rating-value"])
    """
    update P here!
    """
assert ((P > 0).max() > 0.)  # P should not be a 0 matrix.

# sample one valid index and make the value 0 (make it unrated)
rated_indices = list(np.asarray(np.where(P > 0)).T)
sampled_idx = rated_indices[np.random.randint(0, len(rated_indices))]
ground_rating = P[sampled_idx[0], sampled_idx[1]]
P[sampled_idx[0], sampled_idx[1]] = 0.


# Parameters
reg = 0.1 # regularization parameter
f = 2 # number of factors

m,n = P.shape
# Random Initialization
# X is (m x f)
# Y is (f x n)
X = 1 - 2*np.random.rand(m,f)
Y = 1 - 2*np.random.rand(f,n)
X *= 0.1
Y *= 0.1

# Alternating Weighted Ridge Regression
"""
Define C here!
"""
for iter in range(20):
  # Solve for X keeping Y fixed
  # Each user u has a different set of weights Cu
  for u, Cu in enumerate(C):
    X[u] = np.linalg.solve(
    np.dot(Y * Cu, Y.T) + reg * np.eye(f),
    np.dot(Y * Cu, P[u])
    )
  # Solve for X keeping Y fixed
  for i,Ci in enumerate(C.T):
    Y[:,i] = np.linalg.solve(
    np.dot(X.T * Ci, X) + reg * np.eye(f),
    np.dot(X.T * Ci, P[:,i].T)
    )
  if iter % 5 == 0:
    print ("iteration %d" % iter)
print ("done")

preds = np.dot(X,Y)

print("====================")
print ("Result Report")
print ("originally user %d rated item %d as %.1f"
       % (sampled_idx[0]+1, sampled_idx[1]+1, ground_rating))
print ("by collaborative filtering we predict the rating as %.1f (error=%.2f)"
       % (preds[sampled_idx[0], sampled_idx[1]], np.abs(preds[sampled_idx[0], sampled_idx[1]] - ground_rating)))