"""
KAIST X Samsung SDS AI Lecture
Topic: association rule
Lecturer: Sung-Eui Yoon (sungeui@kaist.edu)

Code by Woobin Im (iwbn@kaist.ac.kr)
"""

import numpy as np  # numpy: scientific computation
import pandas as pd   # pandas: data analysis
from apyori import apriori

# you can load csv file
store_data = pd.read_csv("GroceryStoreDataSet.csv", names=['A'])

# but you need this line because `pd.read_csv` doesn't properly parse the file
# since it has different column count for each row.
store_data = store_data.A.str.split(',')

# extracts association rules from data
results = apriori(store_data)

# empty `DataFrame` with columns
results_frame = pd.DataFrame(columns=['Item', "Support"])

# loop through the results
for record in results:
    # convert results into dictionary type
    converted_record = record._replace(
        ordered_statistics=[x._asdict() for x in record.ordered_statistics])
    converted_record = converted_record._asdict()

    # sort items alphabetically
    items_list = sorted(list(converted_record['items']))

    # append a row to results_frame
    toappend = pd.DataFrame([[','.join(items_list), converted_record['support']]], columns=['Item', "Support"])
    results_frame = results_frame.append(toappend)

results_frame = results_frame.set_index("Item")

"""
Define 3 functions here!
If not inferenced from the records, each function should return -1
"""


def support(X):
    raise NotImplementedError


def confidence(X, Y):
    raise NotImplementedError


def lift(X, Y):
    raise NotImplementedError

if __name__ == "__main__":
    # confidence value for "JAM=>BREAD"
    conf = confidence(("BREAD", "JAM"), ("JAM"))
    print('confidence(("BREAD", "JAM"), ("JAM")) = %.4f' % conf)  # this should print 1.0000
