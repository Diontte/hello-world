##point estimation and interval estimation
#�ŷڱ����� ����: ǥ���� ũ�Ⱑ Ŭ ��  
install.packages("robustbase")
data(NOxEmissions, package="robustbase")
x = NOxEmissions$LNOx
n=length(x)
se=sd(x)/sqrt(n)
a=0.05; z=qnorm(1-a/2)
m=mean(x)
ci=m+c(-z*se,z*se)
cat("95% confidence intervals:",ci,"\n")
t.test(x)[4]

#�ŷڱ����� ����: ǥ���� ũ�Ⱑ ���� ��  
x=c(446,450,458,452,456,462,449,460,467,455)
m=mean(x)
n=length(x)
a=0.05; tc=qt(1-a/2,n-1)
se=sd(x)/sqrt(n)
ci=m+c(-tc,tc)*se
cat("Confidence intervals:", ci, "for x\n")


## 1. One-Sample t Test ##
# two-tailed one sample t test
daily.intake<-c(5260, 5470, 5640, 6180, 6390, 6515, 6805, 7515, 7515, 8230, 8770)
a=0.05; df2=length(daily.intake)-1
t.crit=qt(a/2,df2);t.crit
m=7725
t.test(daily.intake, mu=m)
mean(daily.intake) -m

#Independent Two Sample t-test
install.packages("ISwR")
install.packages("gplots")
data(energy, package="ISwR")
str(energy)
head(energy)

# two-sided t.test #
var.test(expend~stature, data=energy)$p.value
ts <- t.test(expend~stature, var.equal=TRUE, data=energy)
ts
a = 0.05; dfn=ts$parameter
tc <- qt(a/2,df=dfn); tc

#Plot group means and confidence intervals
library(gplots)
plotmeans(expend~stature, data=energy, digits=3, mean.label=TRUE,main="Energy Expenditures by stature")

#Paired t-test
dt <- read.csv("PrePost.csv", header = T)
head(dt)
pt<-t.test(dt$x1,dt$x2, paired=TRUE)
pt
t=round(pt$statistic,3); t
dfp=pt$parameter; a=0.05;
tc=round(qt(a/2,df=dfp),3); tc

