#Univariate Analysis(�Ϻ����м�)

install.packages("boot")
install.packages("psych")

## Continuous variable
#Input paulsen dataset & data structure and summary
data(paulsen, package="boot")
View(paulsen)
class(paulsen)
dim(paulsen)
length(paulsen$y)
str(paulsen)
summary(paulsen)
var(paulsen$y)
psych::describe(paulsen)

##Data Visualizations
#Frequency distribution histogram
y=paulsen$y
hist(y,breaks=20,main=NULL,xlab="Current")

#Density distribution histogram
hist(y,breaks=20,main=NULL,xlab="Current",freq=F)
lines(density(y),col=2)

#plot
boxplot(y,ylab="current")
barplot(y,ylab="current")


#A categorical and continuous variable
install.packages("ggplot2")
install.packages("dplyr")
install.packages("Rmisc")
install.packages("ztable")
install.packages("ggridges")

data(diamonds, package="ggplot2")
diamonds[1:4,]
library(dplyr)
dia2 <- diamonds%>% select(carat,cut)
diamonds
dia2
class(dia2)
dim(dia2)
length(dia2$carat)
str(dia2)
summary(dia2)

#descriptive statistics for carat variable
var(dia2$carat)
psych::describe(dia2$carat)
#descriptive statistics for cut variable
td=table(dia2$cut)
addmargins(td)
prop.table(td)
#descriptive statistics of carat grouped by cut
d2x=Rmisc::summarySE(dia2,measurevar="carat",groupvars="cut")
ztable::ztable(d2x)
#Data visualizations
barplot(d2x$carat, names.arg=d2x$cut, col=2:6, xlab='cut', ylab='average carat')
boxplot(carat~cut, data=dia2,col=2:6, xlab='cut',ylab='carat')
barplot(d2x$N,names.arg=d2x$cut,col=2:6, xlab='cut', ylab='count')
dlabel=paste(d2x$cut, round(prop.table(td)*100,2),"%")
pie(d2x$N, labels=dlabel)
library(ggplot2)
ggplot(dia2, aes(x=carat, color=cut)) + geom_freqpoly(binwidth=0.1)
library(ggridges)
ggplot(dia2,aes(x=carat,y=cut,fill=cut)) + geom_density_ridges()+theme_ridges()+theme(legend.position="none")



#Two continuous variables (�� ���Ӻ���) 
class(faithful)
dim(raithful)
str(faithful)
summary(faithful)
pdf=psych::describe(faithful)
ztable::ztable(pdf)
var(faithful$eruptions)
var(faithful$waiting)

#Correlation 
install.packages("ggpubr")
head(swiss)
library(ggpubr)
ggscatter(swiss, x="Examination", y="Education", add="reg.line", conf.int=TRUE, add.params = list(color="blue", fill="lightgray"), cor.coef=TRUE, cor.method="pearson")
