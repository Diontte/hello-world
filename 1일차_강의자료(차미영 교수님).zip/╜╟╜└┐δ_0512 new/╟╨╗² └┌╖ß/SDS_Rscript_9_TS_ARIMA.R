rm(list=ls())

library(fpp)
data(elecequip)

# Stationarity Test
plot(elecequip)
adf.test(elecequip)
kpss.test(elecequip)
kpss.test(elecequip, "Trend")

# ACF / PACF
a1 = acf(elecequip); a1
a2 = pacf(elecequip); a2
tsdisplay(elecequip)

# ARIMA
am <- auto.arima(elecequip); am
tsdiag(am)

fo <- forecast(am, h=10); fo; plot(fo)
lines(am$fitted, col="red", lty=2, lwd=2)
