# Refreshing the global environment - always necessary
rm(list=ls())

install.packages("fpp")
library(fpp)
data(elecsales); elecsales
mm1 = stats::filter(elecsales, filter=rep(1,4)/4, method="convolution", sides=1); mm1 # rep(1,4)/4 = c(0.25 0.25 0.25 0.25)
plot(elecsales, main="Simple Moving Average Smoothing : elecsales")
lines(mm1, col="red", lty=2, lwd=2)


# Weighted Moving Average
w1 = c(0.4, 0.3, 0.2, 0.1)
(mm2 = filter(elecsales, filter=w1, method="convolution", sides=1))
plot(elecsales, main="Weight Moving Average Smoothing")
lines(mm2, col="red", lty=2,lwd=2)

# Residual Diagnostic
res = mm2[-1:-3]- elecsales[-1:-3]
tsdisplay(res)
Box.test(res)


# Exponential Smoothing using Holt-Winters Method
data(austourists)
ho <- hw(austourists)
summary(ho)
plot(ho)
lines(ho$fitted, col="red", lty=2, lwd=2)

tsdisplay(ho$residuals)
Box.test(ho$residuals)

fo <- forecast(ho, h=4); fo
accuracy(fo)

