x <- 100; x
k <<- c("Mary","Jackson"); k
c(100,200) -> y;y
y <- c(100,200); y
45 ->> x; x
z = x; z

125+371-124
3^20
375/27
375%/%27
4*507
567%%2

plot(USArrests)

options(digits=2)
cor(USArrests)

lm(dist~speed, data=cars)

C=seq(0,100,10)
F <- C*9/5+32
T <- data.frame(Celsius=C, Fahrenheit=F)
T


#(1) Command Options
ls() #To see the names of all objects in your workspace
save.image() #Save contents of workspace, into the file ".RData"
save.image(file="myscript.RData") #Save into the file "myscript.RData"

#(2) Manipulating R Objects
seq(0, 120, 20)
rep(1:5,2)

x1 <- c(3, 1, 4, 15, 92)
rank(x1)
x2 <- c(3, 1, 4, 6, 5, 9)
rev(x2)
x3 <- c(3:5, 11:8, 8 + 0:5)
unique(x3)


#(1) Vectors
vector1 <- c(10,20,30,40,50,60) #Numeric Vector 
vector1
vector2 <- c('15','A',"Henry") #Character Vector
vector2
vector3 <- c(T, F, FALSE, TRUE) #Logical vector
vector3

# vector arithmatic
vector1^2
# number of elements
length(vector2)
# vector type
class(vector3)

# Numeric Index Vector
s=c('a','b','c','d','x')
s
s[c(1,3,3,5)]
s[2:4]

# Scalars
a1<- 15
a1
s1<-'Jack'
s1
a2=35
a3=a1+a2
a3

#(2) Matrices
A <- matrix(c(9,2,9,8,8,5,10,8,8,10,3,4),nrow=4)
A
colnames(A) <-c("Plan","Analysis","Writing")
rownames(A) <-c("S1","S2","S3","S4")
A

barplot(A, beside=TRUE,legend=TRUE,col=1:4)

#(3) Arrays
array1 <- array(1:18, dim=c(3,3,2))
array1
dim(array1)
array1[3,3,2]

#(4) Lists
n=c(4,5,7,12)
s=c("and","baby","you","zoo")
b=c(TRUE,FALSE,TRUE,F,T)
x=list(n,s,b)
x
x[[2]]
x[[2]][2]

#(5) Data frame
#Built-in data frames
data()
head(ChickWeight)
#Creating a data frame
Name <- c("Mercury","Venus","Earth","Mars","Jupiter","Saturn","Uranus","Neptune")
Diameter <- c(0.382,0.949,1.0,0.532,11.209,9.449,4.007,3.883)
Ring <- c(FALSE, FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,TRUE)
OurPlanets <- data.frame(Name,Diameter,Ring)
OurPlanets

#Factors
dat <- c(1,2,3,3,2,1,3,2,3,2,1,2,3,1,2,3,2,1,2,2)
dat
fct = factor(dat,levels=1:3, labels=c("Small",",Medium","Large"))
fct
plot(fct, col=2:4)
str(fct)
class(fct)
table(fct)
mode(fct)
#To look at the internal representation of numbers, use str():
#http://www.dummies.com/programming/r/how-to-convert-a-factor-in-r/
numbers <-factor(c(9,8,10,8,9))
str(numbers)
