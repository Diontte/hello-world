##Pearson's Chi-Square Test  
install.packages("sjPlot")
install.packages("vcd")

#Chi-square test of goodness of fit
O = c(169, 58, 56, 18, 253, 45, 38, 90)
tc = c("Frequency")
tr = c("Chinese","Indian","Korean","Maori","NZ European","Other European","Pacific","Other")
mo = matrix(O, dimnames=list(tr,tc))
mo
mo <- as.table(mo)
chisq.test(mo)
k=dim(mo)[1]; a=0.05
qchisq(1-a,df=k-1)

#Hanging Chi-Gram
k=length(O); n=sum(O); E=rep(n/k,k)
cgram <- (O-E)/sqrt(E)
barplot(cgram,col=ifelse(cgram>0,"red","blue"),names.arg = tr)


#Chi-square test of independence
dt2 <- read.csv("SurveyData.csv", header=T)
names(dt2)
head(dt2[,1:6])
University <- factor(dt2$univ,levels=1:2,labels=c("Y","K"))
FashionAcceptance <- factor(dt2$c4)
table(University,FashionAcceptance)

#cross table
library(sjPlot) 
sjt.xtab(University, FashionAcceptance, show.col.prc = TRUE, show.row.prc = TRUE)
qchisq(0.95, df=3)

#bar plot
set_theme(geom.label.size=4, axis.textsize = 1.1, legend.pos="bottom")
sjp.xtab(University, FashionAcceptance, type="bar", y.offset=0.01, margin="row",
         coord.flip = TRUE, wrap.labels = 7, geom.colors = "Set2",
         show.summary = TRUE)

#mosaic plot 
library(vcd)
tab2 <- xtabs(~University+FashionAcceptance)
mosaic(tab2, shade=T, legent=T)
