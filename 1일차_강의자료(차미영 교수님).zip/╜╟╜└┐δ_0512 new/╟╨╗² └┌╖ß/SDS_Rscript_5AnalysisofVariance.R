#One-Way ANOVA
str(InsectSprays)
dim(InsectSprays)
head(InsectSprays)
table(InsectSprays$spray)
model=aov(count~spray, data=InsectSprays)
summary(model)
a=0.05; qf(1-a, df1=5, df2=66)
model.tables(model, type='means')
plot.design(InsectSprays)

#Two-Way ANOVA
install.packages("HSAUR3")
install.packages("Rmisc")
data(schooldays, package="HSAUR3")
dim(schooldays)
head(schooldays,2)
attach(schooldays)
table(race)
table(school)
library(Rmisc)
sum = summarySE(schooldays, measurevar="absent", groupvars=c("race","school"))
ztable::ztable(sum)
## Standard error plot using summary statistics
library(ggplot2)
pd = position_dodge(0.3)
ggplot(sum, aes(x=school,y=absent,color=race)) + geom_errorbar(aes(ymin=absent-se,ymax=absent+se), width=0.2,size=0.7,position=pd) +
                geom_point(shape=16, size=3, position=pd) + scale_color_manual(values=c("red","blue")) +theme(legend.position=c(0.13,0.85)) 
#Conducting Two-Way ANOVA
aov2 <- aov(absent~race*school, data=schooldays)
summary(aov2)
#Interaction plot
interaction.plot(x.factor=school,trace.factor=race, response=absent, col=2:3)

##ANCOVA
grow <- read.table("ipomopsis.txt", header=T)
str(grow)
attach(grow)
table(Grazing)

#Linear regression lines for the two grazing treatments
plot(Root, Fruit, col=ifelse(Grazing=="Grazed","blue","red"))
abline(lm(Fruit[Grazing=="Grazed"]~Root[Grazing=="Grazed"]),col="blue")
abline(lm(Fruit[Grazing=="Ungrazed"]~Root[Grazing=="Ungrazed"]), col="red")
legend("topleft", legend=c("Grazed","Ungrazed"), pch=c(1,1), col=c("blue","red"))
tapply(Fruit, Grazing, mean)

#Linear regression and ANOVA
fitlm <- lm(Fruit~Grazing*Root)
summary(fitlm)

fitlm2 <- update(fitlm,~.-Grazing:Root)
anova(fitlm2)

#Determination of valide method
step(fitlm2)

#ANCOVA plot
install.packages("HH")
library(HH)
ancovaplot(Fruit~Root, data=grow, groups=Grazing)
