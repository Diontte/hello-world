##Random Sampling 
#Simulating 10 coin tosses: B=bottom, T=top
sample(c('B','T'),10,replace=T)
#Picking six numbers at random from the set 1:45
sample(1:45,6)

#Probability Distributions
x = c("0","1","2"); y=c(0.25,0.50,0.25)
barplot(y, names.arg = x, xlab="Number of Heads", ylab="Probability", col=rainbow(3))

n=10 
x <- table(rbinom(n,2,0.5))/n; x
barplot(x, xlab="Number of Heads", ylab="Probability", col=rainbow(3))

n= 1e+06
x <- table(rbinom(n,2,0.5))/n; x
barplot(x, xlab="Number of Heads", ylab="Probability", col=rainbow(3)) 


##Normal distribution
#A standard normal distribution curve
x1=-4; x2=4
x<-seq(x1,x2,0.1); y<-dnorm(x)
plot(x,y,type='l',xlim=c(x1,x2),ylim=c(0,0.4), xlab="x",ylab="Probability Density")

#Normality test
dt<-read.csv("score80.csv")
x <- dt$x
hist(x, freq=F, breaks=20, col="cyan", xlab="score", main=NULL)
lines(density(x), col=2)
shapiro.test(x)   # ���Ժ����� ������ ���� ��� �Ǵ��Ѵ�.

#Area Under the Normal Curve
x=seq(-4,4,length=200)
m <- mean(x); s<-sd(x)
s1<-pnorm(m+s,m,s)
s0<-pnorm(m,m,s)
s1-s0
(s10<-round(s1-s0,4)*100)
s2<-pnorm(m+2*s, m,s)
s2-s1
(s21<-round(s2-s1,4)*100)


#t-Distribution
plot(function(x) dt(x,df=10),-4,4,ylim=c(0,0.4))

#comparing density distributions
labels=c("df=1","df=5","normal")
curve(dnorm(x),-4,4,200,col=2,ylab="")
curve(dt(x,df=1),-4,4,200,col=3,add=T)
curve(dt(x,df=5),-4,4,200,col=4,add=T)
lab=c("normal","df=1","df=5")
legend("topright",lab,lty=1,col=2:4)

#Chi-squared Distribution 
x=seq(0,8,0.1); cols=c(2:5)
k=c(1,3,5,7); k_label=c('k=1','k=3','k=5','k=7')
plot(c(0,8),c(0,1),type="n",xlab="x",ylab="Chi-squared density")
for(i in 1:40){lines(x,dchisq(x,df=k[i]),col=cols[i])}
legend('topright',k_label,col=2:5,lwd=1)
 