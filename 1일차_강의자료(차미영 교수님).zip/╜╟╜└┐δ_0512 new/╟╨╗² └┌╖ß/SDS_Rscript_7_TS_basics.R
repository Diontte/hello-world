dd = matrix(c (1342, 1442, 1252, 1343,  1425, 1362, 1456, 1272,
               1243, 1359, 1412, 1253,  1201, 1478, 1322, 1406,
               1254, 1289, 1497, 1208))
dd.ts = ts(data=dd, start=c(2006,1), frequency=4); dd.ts

class(dd.ts)
start(dd.ts)
end(dd.ts)
frequency(dd.ts)
dd.ts.2 <- dd.ts/2; dd.ts.2
dd.ts.lag <- lag(dd.ts, k=3); dd.ts.lag
dd.ts.diff <- diff(dd.ts); dd.ts.diff

plot(dd.ts, main="Time Series Data")

# Window   �ð迭 �����Ͱ� ũ�Ƿ� Ư���κи� ������ �Ҷ� �����ϴ�.
window(dd.ts, c(2007,2), c(2008,3))
window(dd.ts, s=c(2006,2), delta=1)


# Basic Decomposition
install.packages("TSA")
library(TSA)
data(airpass)
plot(decompose(airpass, type="multiplicative"))
ddd <- decompose(airpass, type="multiplicative")
plot(airpass/ddd$seasonal, main="Without seasonal variation")
plot(airpass/ddd$trend, main="Without trend variation")