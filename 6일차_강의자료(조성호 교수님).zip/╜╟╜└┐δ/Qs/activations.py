import numpy as np 

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

# Problem 2. Define each activation function below.

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

def sigmoid(Z):
    return Z

def relu(Z):
    return Z

def sigmoid_backward(delta, Z):
    return Z

def relu_backward(delta, Z):
    return Z