import numpy as np


def init_layers(nn_architecture, seed = 99):
    # Do not modify here.
    np.random.seed(seed)
    number_of_layers = len(nn_architecture)
    params_values = {}
    
    for idx, layer in enumerate(nn_architecture):
        layer_idx = idx + 1
        
        layer_input_size = layer["input_dim"]
        layer_output_size = layer["output_dim"]

        params_values['W' + str(layer_idx)] = np.random.randn(
            layer_output_size, layer_input_size) * 0.1
        params_values['b' + str(layer_idx)] = np.random.randn(
            layer_output_size, 1) * 0.1
        
    return params_values


def single_layer_forward_propagation(A_prev, W_curr, b_curr, activation="relu"):
    import activations
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #
    
    # Problem 3. Define the output function Z_curr
    
    Z_curr = # Fill in here
    
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

    if activation is "relu":
        activation_func = activations.relu
    elif activation is "sigmoid":
        activation_func = activations.sigmoid
    else:
        raise Exception('Non-supported activation function')
    

    return activation_func(Z_curr), Z_curr


def single_layer_backward_propagation(dA_curr, W_curr, b_curr, Z_curr, A_prev, activation="relu"):
    # Do not modify here.
    import activations
    
    if activation is "relu":
        backward_activation_func = activations.relu_backward
    elif activation is "sigmoid":
        backward_activation_func = activations.sigmoid_backward
    else:
        raise Exception('Non-supported activation function')
    
    m = A_prev.shape[1]

    # chain rule

    dZ_curr = backward_activation_func(dA_curr, Z_curr)
    
    dW_curr = np.dot(dZ_curr, A_prev.T) / m
    db_curr = np.sum(dZ_curr, axis=1, keepdims=True) / m
    dA_prev = np.dot(W_curr.T, dZ_curr)

    return dA_prev, dW_curr, db_curr



def full_forward_propagation(X, params_values, nn_architecture):
    # Do not modify here.
    memory = {}
    A_curr = X
    
    for idx, layer in enumerate(nn_architecture):
        layer_idx = idx + 1
        A_prev = A_curr
        
        activ_function_curr = layer["activation"]
        W_curr = params_values["W" + str(layer_idx)]
        b_curr = params_values["b" + str(layer_idx)]
        A_curr, Z_curr = single_layer_forward_propagation(A_prev, W_curr, b_curr, activ_function_curr)
        
        memory["A" + str(idx)] = A_prev
        memory["Z" + str(layer_idx)] = Z_curr
       
    return A_curr, memory




def full_backward_propagation(Y_hat, Y, memory, params_values, nn_architecture):
    # Do not modify here.
    grads_values = {}

    m = Y.shape[1]
    Y = Y.reshape(Y_hat.shape)
    
    dA_prev = - (np.divide(Y, Y_hat) - np.divide(1 - Y, 1 - Y_hat));
    
    for layer_idx_prev, layer in reversed(list(enumerate(nn_architecture))):
        layer_idx_curr = layer_idx_prev + 1
        activ_function_curr = layer["activation"]
        
        dA_curr = dA_prev
        
        A_prev = memory["A" + str(layer_idx_prev)]
        Z_curr = memory["Z" + str(layer_idx_curr)]
        
        W_curr = params_values["W" + str(layer_idx_curr)]
        b_curr = params_values["b" + str(layer_idx_curr)]
        
        dA_prev, dW_curr, db_curr = single_layer_backward_propagation(
            dA_curr, W_curr, b_curr, Z_curr, A_prev, activ_function_curr)
        
        grads_values["dW" + str(layer_idx_curr)] = dW_curr
        grads_values["db" + str(layer_idx_curr)] = db_curr
    
    return grads_values




def update(params_values, grads_values, nn_architecture, learning_rate):
    for layer_idx, layer in enumerate(nn_architecture, 1):
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

        # Problem 4. update params_values that contain updated W and b

        # W to update: params_values["W" + CURRENT_INDEX]
        # dW: grads_values["dW" + CURRENT_INDEX]
        # b to update: params_values["b" + CURRENT_INDEX]
        # db: grads_values["db" + CURRENT_INDEX]

        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

    return params_values




def keras_layers():
    from keras.models import Sequential
    from keras.layers import Dense
    from keras import optimizers

    model = Sequential()
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #
    
    # Problem 6. Define Keras model here.

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #    
    model.add(Dense(1,activation = 'sigmoid'))
    # Problem 7. Modify lr to have accuracy higher than 98%.
    
    optimizer_ = optimizers.SGD(lr=0.01, momentum=0.0, decay=0.0, nesterov=False)

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

    model.compile(loss='binary_crossentropy', optimizer=optimizer_, metrics=['accuracy'])

    return model

    