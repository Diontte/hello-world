import numpy as np 

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

# Problem 2. Define each activation function below.

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

def sigmoid(Z):
	return 1/(1+np.exp(-Z))

def relu(Z):
	return np.maximum(0,Z)

def sigmoid_backward(delta, Z):
	sig = sigmoid(Z)
	return delta*(1-sig)*sig

def relu_backward(delta, Z):
	dZ = np.array(delta, copy =True)
	dZ[Z<=0] =0
	return dZ