import layers_and_propagators as lp
import utils

import numpy as np
import os
import keras
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from IPython.display import Image
import warnings
warnings.filterwarnings("ignore")

NN_ARCHITECTURE = [
    {"input_dim": 2, "output_dim": 25, "activation": "relu"},
    {"input_dim": 25, "output_dim": 50, "activation": "relu"},
    {"input_dim": 50, "output_dim": 50, "activation": "relu"},
    {"input_dim": 50, "output_dim": 25, "activation": "relu"},
    {"input_dim": 25, "output_dim": 1, "activation": "sigmoid"},
]

N_SAMPLES = 1000
TEST_SIZE = 0.1
OUTPUT_DIR = "./plot/"

GRID_X_START = -1.5
GRID_X_END = 2.5
GRID_Y_START = -1.0
GRID_Y_END = 2


def train(X, Y, nn_architecture, epochs, learning_rate, verbose=False, callback=None):
	# Do not modify here.
	params_values = lp.init_layers(nn_architecture, 2)
	cost_history = []
	accuracy_history = []

	for i in range(epochs):
		if((i+1)%100 == 1):
			print("training in progess: ",i," / ",epochs)
		Y_hat, cashe = lp.full_forward_propagation(X, params_values, nn_architecture)

		cost = utils.get_cost_value(Y_hat, Y)
		cost_history.append(cost)
		accuracy = utils.get_accuracy_value(Y_hat, Y)
		accuracy_history.append(accuracy)

		grads_values = lp.full_backward_propagation(Y_hat, Y, cashe, params_values, nn_architecture)
		params_values = lp.update(params_values, grads_values, nn_architecture, learning_rate)

		if(i % 50 == 0):
			if(verbose):
				print("Iteration: {:05} - cost: {:.5f} - accuracy: {:.5f}".format(i, cost, accuracy))
			if(callback is not None):
				callback(i, params_values)
            
	return params_values



def main():
	def callback_keras_plot(epoch, logs):
		# Do not modify here.
		import os

		plot_title = "Keras Model - It: {:05}".format(epoch)
		file_name = "keras_model_{:05}.png".format(epoch)
		file_path = os.path.join(OUTPUT_DIR, file_name)
		prediction_probs = model.predict_proba(grid_2d, batch_size=32, verbose=0)
		utils.make_plot(X_test, y_test, plot_title, file_name=file_path, XX=XX, YY=YY, preds=prediction_probs)


	def callback_numpy_plot(index, params):
		# Do not modify here.
	    plot_title = "NumPy Model - It: {:05}".format(index)
	    file_name = "numpy_model_{:05}.png".format(index//50)
	    file_path = os.path.join(OUTPUT_DIR, file_name)
	    prediction_probs, _ = lp.full_forward_propagation(np.transpose(grid_2d), params, NN_ARCHITECTURE)
	    prediction_probs = prediction_probs.reshape(prediction_probs.shape[1], 1)
	    utils.make_plot(X_test, y_test, plot_title, file_name=file_path, XX=XX, YY=YY, preds=prediction_probs, dark=True)

	# Do not modify here
	grid = np.mgrid[GRID_X_START:GRID_X_END:100j,GRID_X_START:GRID_Y_END:100j]
	grid_2d = grid.reshape(2, -1).T
	XX, YY = grid
	testmodelcb = keras.callbacks.LambdaCallback(on_epoch_end=callback_keras_plot)


    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

	# Problem 1. load x.csv and y.csv here

	X = np.loadtxt("x.csv",delimiter =",")# fill in here
	y = np.loadtxt("y.csv",delimiter =",")# fill in here


    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #


	X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=TEST_SIZE, random_state=42)

	# utils.make_plot(X, y, "Dataset")
	# print("start training")
	# params_values = train(np.transpose(X_train), np.transpose(y_train.reshape((y_train.shape[0], 1))), NN_ARCHITECTURE, 10000, 0.01, False, callback_numpy_plot)

	# Y_test_hat, _ = lp.full_forward_propagation(np.transpose(X_test), params_values, NN_ARCHITECTURE)
	# acc_test = utils.get_accuracy_value(Y_test_hat, np.transpose(y_test.reshape((y_test.shape[0], 1))))
	# print("Test set accuracy using numpy: {:.2f} ".format(acc_test))

	# prediction_probs_numpy, _ = lp.full_forward_propagation(np.transpose(grid_2d), params_values, NN_ARCHITECTURE)
	# prediction_probs_numpy = prediction_probs_numpy.reshape(prediction_probs_numpy.shape[1], 1)
	# utils.make_plot(X_test, y_test, "NumPy Model", file_name=None, XX=XX, YY=YY, preds=prediction_probs_numpy)
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

	# Problem 5. Check your test result. Before proceed to Problem 6, uncomment below 5 lines.

	# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #

	model = lp.keras_layers()
	history = model.fit(X_train, y_train, epochs=200, verbose=1 , callbacks=[testmodelcb])
	Y_test_hat = model.predict_classes(X_test)
	acc_test = accuracy_score(y_test, Y_test_hat)
	print("Test set accuracy: {:.2f}".format(acc_test))


if __name__ == "__main__":
	main()