import numpy as np

def get_cost_value(Y_hat, Y):
	# Do not modify here.
    m = Y_hat.shape[1]
    cost = -1 / m * (np.dot(Y, np.log(Y_hat).T) + np.dot(1 - Y, np.log(1 - Y_hat).T))
    return np.squeeze(cost)


def convert_prob_into_class(probs):
	# Do not modify here.
    probs_ = np.copy(probs)
    probs_[probs_ > 0.5] = 1
    probs_[probs_ <= 0.5] = 0
    return probs_

def get_accuracy_value(Y_hat, Y):
	# Do not modify here.
    Y_hat_ = convert_prob_into_class(Y_hat)
    return (Y_hat_ == Y).all(axis=0).mean()

def make_plot(X, y, plot_name, file_name=None, XX=None, YY=None, preds=None, dark=False):
	# Do not modify here.
	import seaborn as sns
	import matplotlib.pyplot as plt
	from matplotlib import cm


	if (dark):
		plt.style.use('dark_background')
	else:
		sns.set_style("whitegrid")
	plt.figure(figsize=(16,12))
	axes = plt.gca()
	axes.set(xlabel="$X_1$", ylabel="$X_2$")
	plt.title(plot_name, fontsize=30)
	plt.subplots_adjust(left=0.20)
	plt.subplots_adjust(right=0.80)
	if(XX is not None and YY is not None and preds is not None):
		plt.contourf(XX, YY, preds.reshape(XX.shape), 25, alpha = 1, cmap=cm.Spectral)
		plt.contour(XX, YY, preds.reshape(XX.shape), levels=[.5], cmap="Greys", vmin=0, vmax=.6)
		plt.scatter(X[:, 0], X[:, 1], c=y.ravel(), s=40, cmap=plt.cm.Spectral, edgecolors='black')
	else:
		plt.scatter(X[:, 0], X[:, 1], c=y.ravel(), s=40, cmap=plt.cm.Spectral, edgecolors='black')
		plt.show()

	if(file_name):
		plt.savefig(file_name)
		plt.close()

