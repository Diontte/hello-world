import sys
import os

os.environ['HADOOP_HOME'] = "C:\\spark-2.3.2\\Hadoop"

try:
    #from pyspark import SparkContext
    #from pyspark import SparkConf
    from pyspark.sql import SparkSession
    from pyspark.sql.types import *

    print("Successfully imported Spark Modules")
except ImportError as e:
    print ("Cannot import Spark Modules", e)
    sys.exit(1);


#define schema
movies_columns = [
    StructField("movieId", LongType()),
    StructField("title", StringType()),
    StructField("genres", StringType())
]
links_columns = [
    StructField("movieId", LongType()),
    StructField("imdbId", StringType()),
    StructField("tmdbId", StringType())
]
ratings_columns = [
    StructField("userId", LongType()),
    StructField("movieId", LongType()),
    StructField("rating", FloatType()),
    StructField("timestamp", StringType())
]

movies_schema = StructType(movies_columns)
links_schema = StructType(links_columns)
ratings_schema = StructType(ratings_columns)

spark = SparkSession \
    .builder \
    .appName("Python Spark SQL basic example") \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()

    #include header
df_links = spark.read.schema(links_schema).option("header", "true") \
    .csv("C:\\spark-2.3.2\\SDS-dataset\\links.csv")
df_movies = spark.read.schema(movies_schema).option("header", "true") \
    .csv("C:\\spark-2.3.2\\SDS-dataset\\movies.csv")
df_ratings = spark.read.schema(ratings_schema).option("header", "true") \
    .csv("C:\\spark-2.3.2\\SDS-dataset\\ratings.csv")

#Test whether csv data is successfully loaded
df_movies.show(5)
df_links.show(5)
df_ratings.show(5)

#Test: invoke DataFrame function
df_movies.select(df_movies.title, df_movies.movieId).show(5)

#P1) Create DataFrame df_avg_rating
###################YOUR CODE HERE###########################

df_avg_rating = df_ratings.groupBy("movieId").avg("rating")
print ('<< practice 1 results >>')
df_avg_rating.show()

############################################################

############################################################
#After 1), rename avg(rating) to "users_rating"
df_avg_rating = df_avg_rating.withColumnRenamed("avg(rating)", "users_rating")
#df_avg_rating.show()
############################################################

#P2) Create DataFrame df_movie_info
###################YOUR CODE HERE###########################

df_links_imdb = df_links.select("movieId", "imdbId")
df_movies_info = df_movies.join(df_avg_rating, "movieId") \
    .join(df_links_imdb, "movieId")

print ('<< practice 2 results >>')
df_movies_info.show()
############################################################

#P3) Create dataframe whose contents is the same as df_movie_rating_imdb by SQL statements
df_links.createOrReplaceTempView("links")
df_movies.createOrReplaceTempView("movies")
df_avg_rating.createOrReplaceTempView("avg_rating")

###################YOUR CODE HERE###########################
df_movies_info_sql = spark.sql("SELECT movies.movieID, title, genres, users_rating, imdbId "
                               "FROM links, movies, avg_rating "
                               "WHERE avg_rating.movieId == movies.movieId AND movies.movieId == links.movieId")
print ('<< practice 3 results >>')
df_movies_info_sql.show()
############################################################

#####################Alternative - with original links, movies, ratings dataframes ################
# df_ratings.createOrReplaceTempView("ratings")
#
# df_movies_info_sql = spark.sql("SELECT movies.movieId, title, genres, users_rating, imdbId "
#                     "FROM    (SELECT movieId, avg(rating) AS users_rating "
#                              "FROM ratings "
#                              "GROUP BY MovieId) AS avg_rating, movies, links "
#                     "WHERE avg_rating.movieId == movies.movieId AND movies.movieId == links.movieId")
# df_movies_info_sql.show()
###################################################################################################


#Programming with RDD
rdd_movies = df_movies.rdd

# P4) Count the number of movies for each genre
###################YOUR CODE HERE###########################
rdd_genres = rdd_movies.flatMap(lambda x : x['genres'].split("|"))
rdd_counts = rdd_genres.map(lambda x : (x, 1)) \
             .reduceByKey(lambda x, y : x + y)

# store [(genre, count)] list to rdd_counts
print ('<< practice 4 results >>')
print (rdd_counts.collect())
############################################################



# P5) Create a pair RDD (K, V) rdd_genre_group
###################YOUR CODE HERE###########################
rdd_genre_group = rdd_movies.map(lambda x : (x, x['genres'].split("|"))) \
                .flatMapValues(lambda x : x) \
                .map(lambda x : (x[1], [x[0]])) \
                .reduceByKey(lambda x, y: x+y)
print ('<< practice 5 results >>')
print (rdd_genre_group.take(5))
############################################################


#p6) Create a DataFrame df_gerne_action
###################YOUR CODE HERE###########################
rdd_action = rdd_genre_group.filter(lambda x : x[0] == "Action").flatMap(lambda x : x[1])
df_genre_action = spark.createDataFrame(rdd_action)
print ('<< practice 6 results >>')
df_genre_action.show()
############################################################