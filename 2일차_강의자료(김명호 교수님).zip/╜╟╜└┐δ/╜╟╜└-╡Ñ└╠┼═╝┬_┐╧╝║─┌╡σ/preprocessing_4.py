import pandas as pd
from sklearn import linear_model
from sklearn.metrics import mean_squared_error
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

input_file = "house/train_data.csv"

train_frame = pd.read_csv(input_file)
train_label = train_frame.loc[:,['SalePrice']]
train_frame = train_frame.drop('SalePrice',1)

test_file = "house/test_data.csv"
test_frame = pd.read_csv(test_file)
test_label = test_frame.loc[:,['SalePrice']]
test_frame = test_frame.drop('SalePrice',1)

"""
Data cleaning: processing missing values
1. Fill missing values with mean values 
2. Perform linear regression
3. Calculate MSE (MSE_mean)
"""
sum_lot = 0.0
cnt_lot =0
sum_year = 0.0
cnt_year =0
sum_total = 0.0
cnt_total =0
sum_gr = 0.0
cnt_gr =0
sum_garage = 0.0
cnt_garage =0

for index, row in train_frame.iterrows():
    if not np.isnan(row['LotFrontage']):
        sum_lot += float(row['LotFrontage'])
        cnt_lot +=1
    if not np.isnan(row['YearBuilt']):
        sum_year += float(row['YearBuilt'])
        cnt_year +=1
    if not np.isnan(row['TotalBsmtSF']):
        sum_total += float(row['TotalBsmtSF'])
        cnt_total +=1
    if not np.isnan(row['GrLivArea']):
        sum_gr += float(row['GrLivArea'])
        cnt_gr +=1
    if not np.isnan(row['GarageCars']):
        sum_garage += float(row['GarageCars'])
        cnt_garage +=1

avg_lot = sum_lot/cnt_lot
avg_year = sum_year/cnt_year
avg_total = sum_total/cnt_total
avg_gr = sum_gr/cnt_gr
avg_garage = sum_garage/cnt_garage

train_frame['LotFrontage'] = train_frame['LotFrontage'].fillna(avg_lot)
train_frame['YearBuilt'] = train_frame['YearBuilt'].fillna(avg_year)
train_frame['TotalBsmtSF'] = train_frame['TotalBsmtSF'].fillna(avg_total)
train_frame['GrLivArea'] = train_frame['GrLivArea'].fillna(avg_gr)
train_frame['GarageCars'] = train_frame['GarageCars'].fillna(avg_garage)

sum_lot = 0.0
cnt_lot =0
sum_year = 0.0
cnt_year =0
sum_total = 0.0
cnt_total =0
sum_gr = 0.0
cnt_gr =0
sum_garage = 0.0
cnt_garage =0

for index, row in test_frame.iterrows():
    if not np.isnan(row['LotFrontage']):
        sum_lot += float(row['LotFrontage'])
        cnt_lot += 1
    if not np.isnan(row['YearBuilt']):
        sum_year += float(row['YearBuilt'])
        cnt_year +=1
    if not np.isnan(row['TotalBsmtSF']):
        sum_total += float(row['TotalBsmtSF'])
        cnt_total +=1
    if not np.isnan(row['GrLivArea']):
        sum_gr += float(row['GrLivArea'])
        cnt_gr +=1
    if not np.isnan(row['GarageCars']):
        sum_garage += float(row['GarageCars'])
        cnt_garage +=1

avg_lot = sum_lot / cnt_lot
avg_year = sum_year/cnt_year
avg_total = sum_total/cnt_total
avg_gr = sum_gr/cnt_gr
avg_garage = sum_garage/cnt_garage

test_frame['LotFrontage'] = test_frame['LotFrontage'].fillna(avg_lot)
test_frame['YearBuilt'] = test_frame['YearBuilt'].fillna(avg_year)
test_frame['TotalBsmtSF'] = test_frame['TotalBsmtSF'].fillna(avg_total)
test_frame['GrLivArea'] = test_frame['GrLivArea'].fillna(avg_gr)
test_frame['GarageCars'] = test_frame['GarageCars'].fillna(avg_garage)

H = linear_model.LinearRegression()
H.fit(train_frame, train_label)
predictions = H.predict(test_frame)
mse_mean = mean_squared_error(test_label, predictions)
print("MSE_MEAN: "+str(mse_mean))

"""
Data cleaning: remove outliers
1. Regression-based outlier detection
1) Perform a linear regression and calculate residuals for train data
2) Plot results of linear regression with scatter plot using the matplot library
     - X axis: values of target variable, Y axis: predicted values
3) If a residual > 150,000, then the data point is outlier
4) Remove outliers

2. Evaluation
1) Perform a linear regression using train data without outliers
2) Calculate MSE_out of linear regression using test data
3) Compare MSE_out with MSE_mean
"""
H = linear_model.LinearRegression()
H.fit(train_frame, train_label)
train_prediction=H.predict(train_frame)
residual = np.abs(train_label-train_prediction)
plt.scatter(train_label, train_prediction)
plt.xlabel("real label")
plt.ylabel("predicted label")
plt.show()

drop_list = residual.index[residual['SalePrice']>150000].tolist()
print(drop_list)
train_frame=train_frame.drop(drop_list)
train_label = train_label.drop(drop_list)

H = linear_model.LinearRegression()
H.fit(train_frame, train_label)
predictions = H.predict(test_frame)
result = np.abs(test_label-predictions)
mse_out = mean_squared_error(test_label, predictions)
print("MSE_OUT:"+str(mse_out))

"""
Data transformation: remove non-normality
1. Perform log transformation of ‘LotFrontage’ to remove non-normality
2. Calculate MSE_tran and compare MSE_tran with MSE_out
"""
train_frame["LotFrontage"] = np.log1p(train_frame["LotFrontage"])
test_frame["LotFrontage"] = np.log1p(test_frame["LotFrontage"])

H = linear_model.LinearRegression()
H.fit(train_frame, train_label)
predictions = H.predict(test_frame)

mse_trans = mean_squared_error(test_label, predictions)
print("MSE_TRANS:"+str(mse_trans))

"""
Data reduction: PCA
1. Generate feature vectors by using PCA 
    - The number of components: 20
2. Perform linear regression based on generated feature vectors
3. Calculate MSE_red and compare MSE_tran
"""
pca = PCA(n_components=20)
pc = pca.fit_transform(train_frame)
test_pc = pca.transform(test_frame)

pdf = pd.DataFrame(data=pc)
test_pdf = pd.DataFrame(data=test_pc)

H = linear_model.LinearRegression()
H.fit(pdf, train_label)
predictions = H.predict(test_pdf)
residuals = np.abs(test_label-predictions)
mse_pca = mean_squared_error(test_label, predictions)
print("MSE_PCA: "+str(mse_pca))